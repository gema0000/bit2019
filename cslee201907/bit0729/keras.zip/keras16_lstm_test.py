## keras15_lstm 의 test값을
## 최대한 근접한 predict값을 만든다.
